# Weeman - http server for phishing

This is a copy of the original https://github.com/Hypsurus/weeman repository because the complete account was removed. All credits goes to Hypsurus and the constributers of this project.

HTTP server for phishing in python.
Version 1.7.1 is the last and latest version for weeman.

# Requirements

* Python 2.7

# Platforms

* Linux
* Mac

# Copying

See 'LICENSE' and lib/bs4/COPYING.txt
